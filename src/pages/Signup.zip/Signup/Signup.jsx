import React from "react";
import './Signup.css'
import { useFormik } from "formik";
import { signUpSchema } from "../../Schemas";
import Logo1 from '../../assets/Images/Logo1.png'
import Ficone from '../../assets/Images/fiicon.png'
import Popup from "reactjs-popup";
import { RiArrowDropDownLine } from "react-icons/ri";

const Signup = () => {
    const initialValues = {
        firstname: "",
        lastname: "",
        name: "",
        email: "",
        password: "",
        confirm_password: "",
        CheckMeOut: "",
    };

    const { values, handleBlur, handleChange, handleSubmit, errors, touched } =
        useFormik({
            initialValues,
            validationSchema: signUpSchema,
            validateOnChange: true,
            validateOnBlur: false,
      
            onSubmit: (values, action) => {
                console.log("🚀 val", values);
                action.resetForm();
            },
        });

    console.log(errors);
    return (
        <>

            <div className="container-fluid">
                <div className="constainer maindiv">
                    <div className="row  btndiv">
                        <div className="col-md-10"></div>
                        <div className="col-md-2 btnleft">
                            <Popup trigger={<button className="btnsignup"><img src={Ficone} className="ficone" />English<span className="iconebtn"><RiArrowDropDownLine color="white" size={30} /></span></button>} position="bottom center">
                                <div className="englishkey">
                                    <ul className="englishkeylist">
                                        <li>English</li>
                                        <li>Spanish</li>
                                    </ul>
                                </div>

                            </Popup>

                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-7">
                            <img src={Logo1} className='signupimg'></img>
                            <p className="ptextsigup">
                                <span className="ptextsigup1">Unlock</span> Opportunities<br /><span className="ptextsigup1"> Fuel</span> Ambitions
                            </p>
                            <p className="texth3">The Ultimate Work Marketplace
                            </p>
                            <p className="ptext2">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                        <div className="col-md-5 formdiv">
                            <form onSubmit={handleSubmit}>
                                <div className="formhdiv">
                                    <h2 className="formh">Create account</h2>
                                    <p className="formp">Already have an account? <span className="formpspam">Login here</span></p>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6 formfield">
                                        <label for="firstname1">First Name</label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            name="firstname"
                                            id="firstname1"
                                            placeholder="Enter your first name"
                                            onChange={handleChange}
                                            onBlur={handleBlur} />
                                        {touched.firstname && errors.firstname ? (
                                            <p className="form-error">{errors.firstname}</p>) : null}
                                    </div>
                                    <div class="form-group col-md-6 formfield1">
                                        <label for="lastname1">Last Name</label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            name="lastname"
                                            id="lastname1"
                                            placeholder="Enter your last name"
                                            onChange={handleChange}
                                            onBlur={handleBlur} />
                                        {touched.lastname && errors.lastname ? (
                                            <p className="form-error">{errors.lastname}</p>
                                        ) : null}
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="username1">User Name</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="username1"
                                        placeholder="Enter username"
                                        name="name"
                                        value={values.name}
                                        onChange={handleChange}
                                        onBlur={handleBlur} />
                                    {touched.name && errors.name ? (
                                        <p className="form-error">{errors.name}</p>
                                    ) : null}
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail4">Email</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        id="inputEmail4"
                                        placeholder="Enter your email id"
                                        name="email"
                                        value={values.email}
                                        onChange={handleChange}
                                        onBlur={handleBlur} />
                                    {errors.email && touched.email ? (
                                        <p className="form-error">{errors.email}</p>
                                    ) : null}
                                </div>
                                <div className="row">
                                    <div class="form-group col-md-6 ">
                                        <label for="password">Password</label>
                                        <input
                                            type="password"
                                            class="form-control"
                                            id="password"
                                            placeholder="**********"
                                            name="password"
                                            value={values.password}
                                            onChange={handleChange}
                                            onBlur={handleBlur} />
                                        {errors.password && touched.password ? (
                                            <p className="form-error">{errors.password}</p>
                                        ) : null}
                                    </div>

                                    <div class="form-group col-md-6 ">
                                        <label for="password1">Confirem Password</label>
                                        <input
                                            type="password"
                                            class="form-control"
                                            id="password1"
                                            placeholder="**********"
                                            name="confirm_password"
                                            value={values.confirm_password}
                                            onChange={handleChange}
                                            onBlur={handleBlur} />
                                        {errors.confirm_password && touched.confirm_password ? (
                                            <p className="form-error">{errors.confirm_password}</p>
                                        ) : null}
                                    </div>


                                </div>


                                <div class="form-group">
                                    <div class="form-check">
                                        <input
                                            className="form-check-input maincheckbox"
                                            type="checkbox"
                                            id="gridCheck"
                                            name="CheckMeOut"
                                            value={values.CheckMeOut}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                        />
                                        <label className="form-check-label checkb" for="gridCheck">
                                            I hereby confirm that I’m above the legal age of 18.
                                        </label>
                                        {errors.CheckMeOut && touched.CheckMeOut ? (
                                            <p className="form-error">{errors.CheckMeOut}</p>
                                        ) : null}
                                    </div>
                                </div>
                                <button class="btnsignup1">Sign in</button>
                            </form>
                        </div>

                    </div>

                </div>

            </div>
        </>
    )
}
export default Signup;